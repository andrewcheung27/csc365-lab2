/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM Vocals;
SELECT COUNT(*) FROM Vocals;


SELECT * FROM Performance;
SELECT COUNT(*) FROM Performance;


SELECT * FROM Instruments;
SELECT COUNT(*) FROM Instruments;


SELECT * FROM Tracklists;
SELECT COUNT(*) FROM Tracklists;


SELECT * FROM Albums;
SELECT COUNT(*) FROM Albums;


SELECT * FROM Songs;
SELECT COUNT(*) FROM Songs;


SELECT * FROM Band;
SELECT COUNT(*) FROM Band;


