/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


INSERT INTO Albums
VALUES(1, 'Le Pop', 2008, 'Propeller Recordings', 'Studio');

INSERT INTO Albums
VALUES(2, 'A Kiss Before You Go', 2011, 'Propeller Recordings', 'Studio');

INSERT INTO Albums
VALUES(3, 'A Kiss Before You Go: Live in Hamburg', 2012, 'Universal Music Group', 'Live');

INSERT INTO Albums
VALUES(4, 'Rockland', 2015, 'Propeller Recordings', 'Studio');

