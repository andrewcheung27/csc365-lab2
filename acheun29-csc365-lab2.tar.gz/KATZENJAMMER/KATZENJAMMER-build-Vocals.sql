/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


INSERT INTO Vocals
VALUES(2, 1, 'lead');

INSERT INTO Vocals
VALUES(2, 3, 'chorus');

INSERT INTO Vocals
VALUES(2, 4, 'chorus');

INSERT INTO Vocals
VALUES(3, 2, 'lead');

INSERT INTO Vocals
VALUES(4, 1, 'chorus');

INSERT INTO Vocals
VALUES(4, 2, 'lead');

INSERT INTO Vocals
VALUES(4, 3, 'chorus');

INSERT INTO Vocals
VALUES(4, 4, 'chorus');

INSERT INTO Vocals
VALUES(5, 2, 'lead');

INSERT INTO Vocals
VALUES(5, 1, 'chorus');

INSERT INTO Vocals
VALUES(5, 3, 'chorus');

INSERT INTO Vocals
VALUES(5, 4, 'chorus');

INSERT INTO Vocals
VALUES(6, 4, 'lead');

INSERT INTO Vocals
VALUES(6, 1, 'lead');

INSERT INTO Vocals
VALUES(7, 4, 'lead');

INSERT INTO Vocals
VALUES(7, 2, 'lead');

INSERT INTO Vocals
VALUES(7, 3, 'chorus');

INSERT INTO Vocals
VALUES(8, 1, 'chorus');

INSERT INTO Vocals
VALUES(8, 2, 'chorus');

INSERT INTO Vocals
VALUES(8, 3, 'chorus');

INSERT INTO Vocals
VALUES(8, 4, 'chorus');

INSERT INTO Vocals
VALUES(9, 1, 'lead');

INSERT INTO Vocals
VALUES(9, 3, 'chorus');

INSERT INTO Vocals
VALUES(10, 3, 'lead');

INSERT INTO Vocals
VALUES(10, 1, 'chorus');

INSERT INTO Vocals
VALUES(10, 2, 'chorus');

INSERT INTO Vocals
VALUES(11, 1, 'chorus');

INSERT INTO Vocals
VALUES(11, 2, 'chorus');

INSERT INTO Vocals
VALUES(11, 3, 'lead');

INSERT INTO Vocals
VALUES(11, 4, 'chorus');

INSERT INTO Vocals
VALUES(12, 1, 'chorus');

INSERT INTO Vocals
VALUES(12, 2, 'chorus');

INSERT INTO Vocals
VALUES(12, 3, 'chorus');

INSERT INTO Vocals
VALUES(12, 4, 'lead');

INSERT INTO Vocals
VALUES(13, 2, 'lead');

INSERT INTO Vocals
VALUES(13, 1, 'chorus');

INSERT INTO Vocals
VALUES(13, 3, 'chorus');

INSERT INTO Vocals
VALUES(14, 4, 'lead');

INSERT INTO Vocals
VALUES(15, 1, 'lead');

INSERT INTO Vocals
VALUES(15, 2, 'chorus');

INSERT INTO Vocals
VALUES(15, 3, 'chorus');

INSERT INTO Vocals
VALUES(15, 4, 'chorus');

INSERT INTO Vocals
VALUES(16, 1, 'shared');

INSERT INTO Vocals
VALUES(16, 2, 'shared');

INSERT INTO Vocals
VALUES(16, 3, 'chorus');

INSERT INTO Vocals
VALUES(16, 4, 'chorus');

INSERT INTO Vocals
VALUES(17, 2, 'lead');

INSERT INTO Vocals
VALUES(18, 3, 'lead');

INSERT INTO Vocals
VALUES(19, 1, 'lead');

INSERT INTO Vocals
VALUES(19, 3, 'chorus');

INSERT INTO Vocals
VALUES(20, 3, 'lead');

INSERT INTO Vocals
VALUES(20, 4, 'chorus');

INSERT INTO Vocals
VALUES(20, 1, 'chorus');

INSERT INTO Vocals
VALUES(21, 1, 'lead');

INSERT INTO Vocals
VALUES(21, 4, 'chorus');

INSERT INTO Vocals
VALUES(22, 1, 'chorus');

INSERT INTO Vocals
VALUES(22, 2, 'shared');

INSERT INTO Vocals
VALUES(22, 3, 'chorus');

INSERT INTO Vocals
VALUES(22, 4, 'lead');

INSERT INTO Vocals
VALUES(23, 1, 'chorus');

INSERT INTO Vocals
VALUES(23, 2, 'lead');

INSERT INTO Vocals
VALUES(23, 3, 'chorus');

INSERT INTO Vocals
VALUES(23, 4, 'chorus');

INSERT INTO Vocals
VALUES(24, 1, 'chorus');

INSERT INTO Vocals
VALUES(24, 2, 'chorus');

INSERT INTO Vocals
VALUES(24, 3, 'chorus');

INSERT INTO Vocals
VALUES(24, 4, 'chorus');

INSERT INTO Vocals
VALUES(25, 1, 'chorus');

INSERT INTO Vocals
VALUES(25, 2, 'lead');

INSERT INTO Vocals
VALUES(25, 3, 'chorus');

INSERT INTO Vocals
VALUES(25, 4, 'chorus');

INSERT INTO Vocals
VALUES(26, 2, 'lead');

INSERT INTO Vocals
VALUES(26, 1, 'chorus');

INSERT INTO Vocals
VALUES(26, 3, 'chorus');

INSERT INTO Vocals
VALUES(26, 4, 'chorus');

INSERT INTO Vocals
VALUES(27, 4, 'lead');

INSERT INTO Vocals
VALUES(28, 4, 'lead');

INSERT INTO Vocals
VALUES(28, 3, 'chorus');

INSERT INTO Vocals
VALUES(29, 3, 'lead');

INSERT INTO Vocals
VALUES(29, 4, 'chorus');

INSERT INTO Vocals
VALUES(30, 2, 'lead');

INSERT INTO Vocals
VALUES(31, 3, 'shared');

INSERT INTO Vocals
VALUES(31, 4, 'shared');

INSERT INTO Vocals
VALUES(31, 4, 'rap');

INSERT INTO Vocals
VALUES(32, 1, 'shared');

INSERT INTO Vocals
VALUES(32, 2, 'shared');

INSERT INTO Vocals
VALUES(33, 1, 'chorus');

INSERT INTO Vocals
VALUES(33, 2, 'chorus');

INSERT INTO Vocals
VALUES(33, 3, 'lead');

INSERT INTO Vocals
VALUES(33, 4, 'chorus');

INSERT INTO Vocals
VALUES(34, 1, 'shared');

INSERT INTO Vocals
VALUES(34, 3, 'shared');

INSERT INTO Vocals
VALUES(34, 4, 'chorus');

INSERT INTO Vocals
VALUES(35, 1, 'chorus');

INSERT INTO Vocals
VALUES(35, 2, 'lead');

INSERT INTO Vocals
VALUES(35, 3, 'chorus');

INSERT INTO Vocals
VALUES(35, 4, 'chorus');

INSERT INTO Vocals
VALUES(36, 1, 'lead');

INSERT INTO Vocals
VALUES(36, 3, 'chorus');

INSERT INTO Vocals
VALUES(36, 4, 'chorus');

INSERT INTO Vocals
VALUES(37, 1, 'chorus');

INSERT INTO Vocals
VALUES(37, 2, 'chorus');

INSERT INTO Vocals
VALUES(37, 3, 'lead');

INSERT INTO Vocals
VALUES(37, 4, 'chorus');

INSERT INTO Vocals
VALUES(38, 1, 'chorus');

INSERT INTO Vocals
VALUES(38, 2, 'chorus');

INSERT INTO Vocals
VALUES(38, 3, 'chorus');

INSERT INTO Vocals
VALUES(38, 4, 'lead');

INSERT INTO Vocals
VALUES(39, 1, 'lead');

INSERT INTO Vocals
VALUES(39, 3, 'chorus');

INSERT INTO Vocals
VALUES(40, 1, 'chorus');

INSERT INTO Vocals
VALUES(40, 2, 'chorus');

INSERT INTO Vocals
VALUES(40, 3, 'lead');

INSERT INTO Vocals
VALUES(40, 4, 'chorus');

INSERT INTO Vocals
VALUES(41, 1, 'chorus');

INSERT INTO Vocals
VALUES(41, 2, 'lead');

INSERT INTO Vocals
VALUES(41, 3, 'chorus');

INSERT INTO Vocals
VALUES(41, 4, 'chorus');

INSERT INTO Vocals
VALUES(42, 1, 'lead');

INSERT INTO Vocals
VALUES(42, 2, 'chorus');

INSERT INTO Vocals
VALUES(42, 3, 'chorus');

INSERT INTO Vocals
VALUES(42, 4, 'chorus');

INSERT INTO Vocals
VALUES(43, 1, 'chorus');

INSERT INTO Vocals
VALUES(43, 2, 'lead');

INSERT INTO Vocals
VALUES(43, 4, 'chorus');

