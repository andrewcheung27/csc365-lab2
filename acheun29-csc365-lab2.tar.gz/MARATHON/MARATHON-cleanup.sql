DROP TABLE Marathon;
