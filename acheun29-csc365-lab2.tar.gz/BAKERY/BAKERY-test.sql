SELECT * FROM Items;
SELECT COUNT(*) FROM Items;


SELECT * FROM Receipts;
SELECT COUNT(*) FROM Receipts;


SELECT * FROM Customers;
SELECT COUNT(*) FROM Customers;


SELECT * FROM Goods;
SELECT COUNT(*) FROM Goods;


