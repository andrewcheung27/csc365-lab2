/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM CarsData;
SELECT COUNT(*) FROM CarsData;


SELECT * FROM CarNames;
SELECT COUNT(*) FROM CarNames;


SELECT * FROM ModelList;
SELECT COUNT(*) FROM ModelList;


SELECT * FROM CarMakers;
SELECT COUNT(*) FROM CarMakers;


SELECT * FROM Countries;
SELECT COUNT(*) FROM Countries;


SELECT * FROM Continents;
SELECT COUNT(*) FROM Continents;


