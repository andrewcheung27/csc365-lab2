/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


INSERT INTO ModelList
VALUES(1, 1, 'amc');

INSERT INTO ModelList
VALUES(2, 2, 'audi');

INSERT INTO ModelList
VALUES(3, 3, 'bmw');

INSERT INTO ModelList
VALUES(4, 4, 'buick');

INSERT INTO ModelList
VALUES(5, 4, 'cadillac');

INSERT INTO ModelList
VALUES(6, 5, 'capri');

INSERT INTO ModelList
VALUES(7, 4, 'chevrolet');

INSERT INTO ModelList
VALUES(8, 6, 'chrysler');

INSERT INTO ModelList
VALUES(9, 7, 'citroen');

INSERT INTO ModelList
VALUES(10, 8, 'datsun');

INSERT INTO ModelList
VALUES(11, 6, 'dodge');

INSERT INTO ModelList
VALUES(12, 9, 'fiat');

INSERT INTO ModelList
VALUES(13, 5, 'ford');

INSERT INTO ModelList
VALUES(14, 10, 'hi');

INSERT INTO ModelList
VALUES(15, 11, 'honda');

INSERT INTO ModelList
VALUES(16, 12, 'mazda');

INSERT INTO ModelList
VALUES(17, 13, 'mercedes');

INSERT INTO ModelList
VALUES(18, 13, 'mercedes-benz');

INSERT INTO ModelList
VALUES(19, 5, 'mercury');

INSERT INTO ModelList
VALUES(20, 8, 'nissan');

INSERT INTO ModelList
VALUES(21, 4, 'oldsmobile');

INSERT INTO ModelList
VALUES(22, 14, 'opel');

INSERT INTO ModelList
VALUES(23, 15, 'peugeot');

INSERT INTO ModelList
VALUES(24, 6, 'plymouth');

INSERT INTO ModelList
VALUES(25, 4, 'pontiac');

INSERT INTO ModelList
VALUES(26, 16, 'renault');

INSERT INTO ModelList
VALUES(27, 17, 'saab');

INSERT INTO ModelList
VALUES(28, 18, 'subaru');

INSERT INTO ModelList
VALUES(29, 19, 'toyota');

INSERT INTO ModelList
VALUES(30, 20, 'triumph');

INSERT INTO ModelList
VALUES(31, 2, 'volkswagen');

INSERT INTO ModelList
VALUES(32, 21, 'volvo');

INSERT INTO ModelList
VALUES(33, 22, 'kia');

INSERT INTO ModelList
VALUES(34, 23, 'hyundai');

INSERT INTO ModelList
VALUES(35, 6, 'jeep');

INSERT INTO ModelList
VALUES(36, 19, 'scion');

