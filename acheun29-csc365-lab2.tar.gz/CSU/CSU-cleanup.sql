DROP TABLE CsuFees;
DROP TABLE Faculty;
DROP TABLE Enrollments;
DROP TABLE DisciplineEnrollments;
DROP TABLE Degrees;
DROP TABLE Disciplines;
DROP TABLE Campuses;
