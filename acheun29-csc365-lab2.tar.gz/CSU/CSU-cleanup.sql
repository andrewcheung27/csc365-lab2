/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


DROP TABLE CsuFees;
DROP TABLE Faculty;
DROP TABLE Enrollments;
DROP TABLE DisciplineEnrollments;
DROP TABLE Degrees;
DROP TABLE Disciplines;
DROP TABLE Campuses;
