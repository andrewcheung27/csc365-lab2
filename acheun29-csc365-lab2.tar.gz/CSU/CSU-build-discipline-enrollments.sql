INSERT INTO DisciplineEnrollments
VALUES(1, 4, 2004, 248, 0);

INSERT INTO DisciplineEnrollments
VALUES(1, 5, 2004, 811, 73);

INSERT INTO DisciplineEnrollments
VALUES(1, 6, 2004, 199, 0);

INSERT INTO DisciplineEnrollments
VALUES(1, 7, 2004, 179, 0);

INSERT INTO DisciplineEnrollments
VALUES(1, 8, 2004, 293, 422);

INSERT INTO DisciplineEnrollments
VALUES(1, 10, 2004, 164, 0);

INSERT INTO DisciplineEnrollments
VALUES(1, 11, 2004, 60, 6);

INSERT INTO DisciplineEnrollments
VALUES(1, 12, 2004, 457, 35);

INSERT INTO DisciplineEnrollments
VALUES(1, 14, 2004, 1153, 6);

INSERT INTO DisciplineEnrollments
VALUES(1, 15, 2004, 244, 23);

INSERT INTO DisciplineEnrollments
VALUES(1, 17, 2004, 115, 8);

INSERT INTO DisciplineEnrollments
VALUES(1, 18, 2004, 102, 7);

INSERT INTO DisciplineEnrollments
VALUES(1, 19, 2004, 501, 50);

INSERT INTO DisciplineEnrollments
VALUES(1, 20, 2004, 383, 142);

INSERT INTO DisciplineEnrollments
VALUES(1, 21, 2004, 584, 32);

INSERT INTO DisciplineEnrollments
VALUES(1, 22, 2004, 514, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 4, 2004, 155, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 5, 2004, 364, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 7, 2004, 72, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 10, 2004, 127, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 14, 2004, 516, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 15, 2004, 117, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 17, 2004, 60, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 19, 2004, 207, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 21, 2004, 84, 0);

INSERT INTO DisciplineEnrollments
VALUES(2, 22, 2004, 118, 0);

INSERT INTO DisciplineEnrollments
VALUES(3, 1, 2004, 380, 0);

INSERT INTO DisciplineEnrollments
VALUES(3, 2, 2004, 0, 4);

INSERT INTO DisciplineEnrollments
VALUES(3, 3, 2004, 36, 0);

INSERT INTO DisciplineEnrollments
VALUES(3, 4, 2004, 381, 27);

INSERT INTO DisciplineEnrollments
VALUES(3, 5, 2004, 2264, 46);

INSERT INTO DisciplineEnrollments
VALUES(3, 6, 2004, 762, 21);

INSERT INTO DisciplineEnrollments
VALUES(3, 7, 2004, 489, 64);

INSERT INTO DisciplineEnrollments
VALUES(3, 8, 2004, 637, 181);

INSERT INTO DisciplineEnrollments
VALUES(3, 9, 2004, 1298, 25);

INSERT INTO DisciplineEnrollments
VALUES(3, 10, 2004, 836, 25);

INSERT INTO DisciplineEnrollments
VALUES(3, 11, 2004, 108, 0);

INSERT INTO DisciplineEnrollments
VALUES(3, 12, 2004, 426, 60);

INSERT INTO DisciplineEnrollments
VALUES(3, 13, 2004, 113, 16);

INSERT INTO DisciplineEnrollments
VALUES(3, 14, 2004, 1275, 46);

INSERT INTO DisciplineEnrollments
VALUES(3, 15, 2004, 643, 44);

INSERT INTO DisciplineEnrollments
VALUES(3, 17, 2004, 141, 0);

INSERT INTO DisciplineEnrollments
VALUES(3, 18, 2004, 130, 13);

INSERT INTO DisciplineEnrollments
VALUES(3, 19, 2004, 657, 88);

INSERT INTO DisciplineEnrollments
VALUES(3, 20, 2004, 774, 108);

INSERT INTO DisciplineEnrollments
VALUES(3, 21, 2004, 1264, 107);

INSERT INTO DisciplineEnrollments
VALUES(3, 22, 2004, 1665, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 4, 2004, 267, 19);

INSERT INTO DisciplineEnrollments
VALUES(4, 5, 2004, 1502, 72);

INSERT INTO DisciplineEnrollments
VALUES(4, 6, 2004, 233, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 7, 2004, 315, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 8, 2004, 152, 1535);

INSERT INTO DisciplineEnrollments
VALUES(4, 9, 2004, 0, 15);

INSERT INTO DisciplineEnrollments
VALUES(4, 10, 2004, 183, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 11, 2004, 114, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 12, 2004, 882, 377);

INSERT INTO DisciplineEnrollments
VALUES(4, 13, 2004, 0, 55);

INSERT INTO DisciplineEnrollments
VALUES(4, 14, 2004, 1694, 1);

INSERT INTO DisciplineEnrollments
VALUES(4, 15, 2004, 274, 148);

INSERT INTO DisciplineEnrollments
VALUES(4, 17, 2004, 127, 19);

INSERT INTO DisciplineEnrollments
VALUES(4, 18, 2004, 62, 0);

INSERT INTO DisciplineEnrollments
VALUES(4, 19, 2004, 546, 147);

INSERT INTO DisciplineEnrollments
VALUES(4, 20, 2004, 669, 197);

INSERT INTO DisciplineEnrollments
VALUES(4, 21, 2004, 729, 71);

INSERT INTO DisciplineEnrollments
VALUES(4, 22, 2004, 1114, 0);

INSERT INTO DisciplineEnrollments
VALUES(5, 3, 2004, 5, 0);

INSERT INTO DisciplineEnrollments
VALUES(5, 4, 2004, 459, 29);

INSERT INTO DisciplineEnrollments
VALUES(5, 5, 2004, 2675, 729);

INSERT INTO DisciplineEnrollments
VALUES(5, 6, 2004, 302, 33);

INSERT INTO DisciplineEnrollments
VALUES(5, 7, 2004, 495, 222);

INSERT INTO DisciplineEnrollments
VALUES(5, 8, 2004, 221, 436);

INSERT INTO DisciplineEnrollments
VALUES(5, 9, 2004, 104, 0);

INSERT INTO DisciplineEnrollments
VALUES(5, 10, 2004, 551, 17);

INSERT INTO DisciplineEnrollments
VALUES(5, 11, 2004, 28, 0);

INSERT INTO DisciplineEnrollments
VALUES(5, 12, 2004, 446, 153);

INSERT INTO DisciplineEnrollments
VALUES(5, 14, 2004, 942, 16);

INSERT INTO DisciplineEnrollments
VALUES(5, 15, 2004, 296, 118);

INSERT INTO DisciplineEnrollments
VALUES(5, 17, 2004, 133, 134);

INSERT INTO DisciplineEnrollments
VALUES(5, 18, 2004, 81, 29);

INSERT INTO DisciplineEnrollments
VALUES(5, 19, 2004, 850, 0);

INSERT INTO DisciplineEnrollments
VALUES(5, 20, 2004, 428, 297);

INSERT INTO DisciplineEnrollments
VALUES(5, 21, 2004, 823, 140);

INSERT INTO DisciplineEnrollments
VALUES(5, 22, 2004, 874, 0);

INSERT INTO DisciplineEnrollments
VALUES(6, 1, 2004, 776, 40);

INSERT INTO DisciplineEnrollments
VALUES(6, 4, 2004, 533, 43);

INSERT INTO DisciplineEnrollments
VALUES(6, 5, 2004, 2481, 119);

INSERT INTO DisciplineEnrollments
VALUES(6, 6, 2004, 378, 22);

INSERT INTO DisciplineEnrollments
VALUES(6, 7, 2004, 353, 90);

INSERT INTO DisciplineEnrollments
VALUES(6, 8, 2004, 752, 500);

INSERT INTO DisciplineEnrollments
VALUES(6, 9, 2004, 1166, 55);

INSERT INTO DisciplineEnrollments
VALUES(6, 10, 2004, 735, 45);

INSERT INTO DisciplineEnrollments
VALUES(6, 11, 2004, 103, 27);

INSERT INTO DisciplineEnrollments
VALUES(6, 12, 2004, 1634, 382);

INSERT INTO DisciplineEnrollments
VALUES(6, 13, 2004, 62, 128);

INSERT INTO DisciplineEnrollments
VALUES(6, 14, 2004, 2126, 11);

INSERT INTO DisciplineEnrollments
VALUES(6, 15, 2004, 662, 122);

INSERT INTO DisciplineEnrollments
VALUES(6, 17, 2004, 170, 18);

INSERT INTO DisciplineEnrollments
VALUES(6, 18, 2004, 285, 32);

INSERT INTO DisciplineEnrollments
VALUES(6, 19, 2004, 793, 50);

INSERT INTO DisciplineEnrollments
VALUES(6, 20, 2004, 1203, 187);

INSERT INTO DisciplineEnrollments
VALUES(6, 21, 2004, 1010, 82);

INSERT INTO DisciplineEnrollments
VALUES(6, 22, 2004, 1560, 0);

INSERT INTO DisciplineEnrollments
VALUES(7, 3, 2004, 92, 55);

INSERT INTO DisciplineEnrollments
VALUES(7, 4, 2004, 956, 58);

INSERT INTO DisciplineEnrollments
VALUES(7, 5, 2004, 6986, 480);

INSERT INTO DisciplineEnrollments
VALUES(7, 6, 2004, 2263, 95);

INSERT INTO DisciplineEnrollments
VALUES(7, 7, 2004, 835, 378);

INSERT INTO DisciplineEnrollments
VALUES(7, 8, 2004, 2103, 1288);

INSERT INTO DisciplineEnrollments
VALUES(7, 9, 2004, 703, 172);

INSERT INTO DisciplineEnrollments
VALUES(7, 10, 2004, 2152, 202);

INSERT INTO DisciplineEnrollments
VALUES(7, 11, 2004, 158, 38);

INSERT INTO DisciplineEnrollments
VALUES(7, 12, 2004, 695, 249);

INSERT INTO DisciplineEnrollments
VALUES(7, 14, 2004, 1550, 80);

INSERT INTO DisciplineEnrollments
VALUES(7, 15, 2004, 822, 206);

INSERT INTO DisciplineEnrollments
VALUES(7, 17, 2004, 267, 79);

INSERT INTO DisciplineEnrollments
VALUES(7, 18, 2004, 169, 95);

INSERT INTO DisciplineEnrollments
VALUES(7, 19, 2004, 1271, 56);

INSERT INTO DisciplineEnrollments
VALUES(7, 20, 2004, 1396, 135);

INSERT INTO DisciplineEnrollments
VALUES(7, 21, 2004, 1709, 386);

INSERT INTO DisciplineEnrollments
VALUES(7, 22, 2004, 3208, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 1, 2004, 691, 100);

INSERT INTO DisciplineEnrollments
VALUES(8, 4, 2004, 722, 48);

INSERT INTO DisciplineEnrollments
VALUES(8, 5, 2004, 315, 35);

INSERT INTO DisciplineEnrollments
VALUES(8, 6, 2004, 165, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 7, 2004, 130, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 8, 2004, 268, 54);

INSERT INTO DisciplineEnrollments
VALUES(8, 9, 2004, 175, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 10, 2004, 714, 17);

INSERT INTO DisciplineEnrollments
VALUES(8, 11, 2004, 65, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 12, 2004, 278, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 14, 2004, 878, 46);

INSERT INTO DisciplineEnrollments
VALUES(8, 15, 2004, 390, 39);

INSERT INTO DisciplineEnrollments
VALUES(8, 17, 2004, 100, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 18, 2004, 222, 0);

INSERT INTO DisciplineEnrollments
VALUES(8, 19, 2004, 348, 61);

INSERT INTO DisciplineEnrollments
VALUES(8, 20, 2004, 93, 35);

INSERT INTO DisciplineEnrollments
VALUES(8, 21, 2004, 650, 95);

INSERT INTO DisciplineEnrollments
VALUES(8, 22, 2004, 497, 0);

INSERT INTO DisciplineEnrollments
VALUES(9, 2, 2004, 230, 0);

INSERT INTO DisciplineEnrollments
VALUES(9, 3, 2004, 89, 24);

INSERT INTO DisciplineEnrollments
VALUES(9, 4, 2004, 1523, 62);

INSERT INTO DisciplineEnrollments
VALUES(9, 5, 2004, 4087, 301);

INSERT INTO DisciplineEnrollments
VALUES(9, 6, 2004, 980, 0);

INSERT INTO DisciplineEnrollments
VALUES(9, 7, 2004, 486, 122);

INSERT INTO DisciplineEnrollments
VALUES(9, 8, 2004, 867, 650);

INSERT INTO DisciplineEnrollments
VALUES(9, 9, 2004, 2444, 361);

INSERT INTO DisciplineEnrollments
VALUES(9, 10, 2004, 2538, 212);

INSERT INTO DisciplineEnrollments
VALUES(9, 11, 2004, 233, 56);

INSERT INTO DisciplineEnrollments
VALUES(9, 12, 2004, 1478, 504);

INSERT INTO DisciplineEnrollments
VALUES(9, 13, 2004, 986, 124);

INSERT INTO DisciplineEnrollments
VALUES(9, 14, 2004, 2210, 63);

INSERT INTO DisciplineEnrollments
VALUES(9, 15, 2004, 2102, 330);

INSERT INTO DisciplineEnrollments
VALUES(9, 17, 2004, 355, 88);

INSERT INTO DisciplineEnrollments
VALUES(9, 18, 2004, 194, 48);

INSERT INTO DisciplineEnrollments
VALUES(9, 19, 2004, 1197, 67);

INSERT INTO DisciplineEnrollments
VALUES(9, 20, 2004, 1178, 751);

INSERT INTO DisciplineEnrollments
VALUES(9, 21, 2004, 2264, 207);

INSERT INTO DisciplineEnrollments
VALUES(9, 22, 2004, 1945, 1);

INSERT INTO DisciplineEnrollments
VALUES(10, 3, 2004, 30, 38);

INSERT INTO DisciplineEnrollments
VALUES(10, 4, 2004, 660, 63);

INSERT INTO DisciplineEnrollments
VALUES(10, 5, 2004, 2587, 218);

INSERT INTO DisciplineEnrollments
VALUES(10, 6, 2004, 350, 72);

INSERT INTO DisciplineEnrollments
VALUES(10, 7, 2004, 759, 79);

INSERT INTO DisciplineEnrollments
VALUES(10, 8, 2004, 3041, 2514);

INSERT INTO DisciplineEnrollments
VALUES(10, 9, 2004, 714, 207);

INSERT INTO DisciplineEnrollments
VALUES(10, 10, 2004, 691, 207);

INSERT INTO DisciplineEnrollments
VALUES(10, 11, 2004, 161, 64);

INSERT INTO DisciplineEnrollments
VALUES(10, 12, 2004, 1015, 247);

INSERT INTO DisciplineEnrollments
VALUES(10, 13, 2004, 90, 100);

INSERT INTO DisciplineEnrollments
VALUES(10, 14, 2004, 1011, 17);

INSERT INTO DisciplineEnrollments
VALUES(10, 15, 2004, 529, 238);

INSERT INTO DisciplineEnrollments
VALUES(10, 17, 2004, 66, 221);

INSERT INTO DisciplineEnrollments
VALUES(10, 18, 2004, 129, 105);

INSERT INTO DisciplineEnrollments
VALUES(10, 19, 2004, 832, 138);

INSERT INTO DisciplineEnrollments
VALUES(10, 20, 2004, 1271, 356);

INSERT INTO DisciplineEnrollments
VALUES(10, 21, 2004, 1047, 282);

INSERT INTO DisciplineEnrollments
VALUES(10, 22, 2004, 36, 39);

INSERT INTO DisciplineEnrollments
VALUES(11, 5, 2004, 74, 0);

INSERT INTO DisciplineEnrollments
VALUES(11, 9, 2004, 259, 0);

INSERT INTO DisciplineEnrollments
VALUES(11, 14, 2004, 395, 0);

INSERT INTO DisciplineEnrollments
VALUES(11, 21, 2004, 30, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 5, 2004, 509, 27);

INSERT INTO DisciplineEnrollments
VALUES(12, 6, 2004, 546, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 8, 2004, 0, 68);

INSERT INTO DisciplineEnrollments
VALUES(12, 10, 2004, 79, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 14, 2004, 1013, 54);

INSERT INTO DisciplineEnrollments
VALUES(12, 15, 2004, 416, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 17, 2004, 11, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 20, 2004, 131, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 21, 2004, 363, 0);

INSERT INTO DisciplineEnrollments
VALUES(12, 22, 2004, 479, 2);

INSERT INTO DisciplineEnrollments
VALUES(13, 4, 2004, 1195, 81);

INSERT INTO DisciplineEnrollments
VALUES(13, 5, 2004, 5247, 198);

INSERT INTO DisciplineEnrollments
VALUES(13, 6, 2004, 1484, 96);

INSERT INTO DisciplineEnrollments
VALUES(13, 7, 2004, 856, 78);

INSERT INTO DisciplineEnrollments
VALUES(13, 8, 2004, 1366, 1598);

INSERT INTO DisciplineEnrollments
VALUES(13, 9, 2004, 1058, 406);

INSERT INTO DisciplineEnrollments
VALUES(13, 10, 2004, 1517, 135);

INSERT INTO DisciplineEnrollments
VALUES(13, 11, 2004, 118, 28);

INSERT INTO DisciplineEnrollments
VALUES(13, 12, 2004, 815, 422);

INSERT INTO DisciplineEnrollments
VALUES(13, 13, 2004, 622, 93);

INSERT INTO DisciplineEnrollments
VALUES(13, 14, 2004, 2072, 31);

INSERT INTO DisciplineEnrollments
VALUES(13, 15, 2004, 1249, 252);

INSERT INTO DisciplineEnrollments
VALUES(13, 17, 2004, 180, 83);

INSERT INTO DisciplineEnrollments
VALUES(13, 18, 2004, 151, 69);

INSERT INTO DisciplineEnrollments
VALUES(13, 19, 2004, 1697, 78);

INSERT INTO DisciplineEnrollments
VALUES(13, 20, 2004, 413, 14);

INSERT INTO DisciplineEnrollments
VALUES(13, 21, 2004, 2402, 273);

INSERT INTO DisciplineEnrollments
VALUES(13, 22, 2004, 2373, 0);

INSERT INTO DisciplineEnrollments
VALUES(14, 1, 2004, 833, 55);

INSERT INTO DisciplineEnrollments
VALUES(14, 2, 2004, 853, 177);

INSERT INTO DisciplineEnrollments
VALUES(14, 4, 2004, 915, 64);

INSERT INTO DisciplineEnrollments
VALUES(14, 5, 2004, 4850, 156);

INSERT INTO DisciplineEnrollments
VALUES(14, 6, 2004, 297, 0);

INSERT INTO DisciplineEnrollments
VALUES(14, 7, 2004, 600, 69);

INSERT INTO DisciplineEnrollments
VALUES(14, 8, 2004, 274, 245);

INSERT INTO DisciplineEnrollments
VALUES(14, 9, 2004, 3975, 154);

INSERT INTO DisciplineEnrollments
VALUES(14, 10, 2004, 702, 0);

INSERT INTO DisciplineEnrollments
VALUES(14, 11, 2004, 48, 0);

INSERT INTO DisciplineEnrollments
VALUES(14, 13, 2004, 260, 0);

INSERT INTO DisciplineEnrollments
VALUES(14, 14, 2004, 823, 11);

INSERT INTO DisciplineEnrollments
VALUES(14, 15, 2004, 252, 87);

INSERT INTO DisciplineEnrollments
VALUES(14, 17, 2004, 199, 50);

INSERT INTO DisciplineEnrollments
VALUES(14, 18, 2004, 200, 20);

INSERT INTO DisciplineEnrollments
VALUES(14, 19, 2004, 674, 27);

INSERT INTO DisciplineEnrollments
VALUES(14, 20, 2004, 0, 36);

INSERT INTO DisciplineEnrollments
VALUES(14, 21, 2004, 845, 53);

INSERT INTO DisciplineEnrollments
VALUES(14, 22, 2004, 394, 0);

INSERT INTO DisciplineEnrollments
VALUES(15, 2, 2004, 295, 0);

INSERT INTO DisciplineEnrollments
VALUES(15, 3, 2004, 10, 0);

INSERT INTO DisciplineEnrollments
VALUES(15, 4, 2004, 730, 63);

INSERT INTO DisciplineEnrollments
VALUES(15, 5, 2004, 4237, 156);

INSERT INTO DisciplineEnrollments
VALUES(15, 6, 2004, 1239, 53);

INSERT INTO DisciplineEnrollments
VALUES(15, 7, 2004, 877, 176);

INSERT INTO DisciplineEnrollments
VALUES(15, 8, 2004, 1260, 1388);

INSERT INTO DisciplineEnrollments
VALUES(15, 9, 2004, 1534, 330);

INSERT INTO DisciplineEnrollments
VALUES(15, 10, 2004, 1135, 65);

INSERT INTO DisciplineEnrollments
VALUES(15, 11, 2004, 120, 50);

INSERT INTO DisciplineEnrollments
VALUES(15, 12, 2004, 1372, 271);

INSERT INTO DisciplineEnrollments
VALUES(15, 13, 2004, 275, 0);

INSERT INTO DisciplineEnrollments
VALUES(15, 14, 2004, 1398, 77);

INSERT INTO DisciplineEnrollments
VALUES(15, 15, 2004, 608, 244);

INSERT INTO DisciplineEnrollments
VALUES(15, 17, 2004, 195, 31);

INSERT INTO DisciplineEnrollments
VALUES(15, 18, 2004, 307, 35);

INSERT INTO DisciplineEnrollments
VALUES(15, 19, 2004, 1037, 96);

INSERT INTO DisciplineEnrollments
VALUES(15, 20, 2004, 1961, 519);

INSERT INTO DisciplineEnrollments
VALUES(15, 21, 2004, 1729, 296);

INSERT INTO DisciplineEnrollments
VALUES(15, 22, 2004, 2467, 0);

INSERT INTO DisciplineEnrollments
VALUES(16, 3, 2004, 4, 0);

INSERT INTO DisciplineEnrollments
VALUES(16, 4, 2004, 585, 13);

INSERT INTO DisciplineEnrollments
VALUES(16, 5, 2004, 2115, 229);

INSERT INTO DisciplineEnrollments
VALUES(16, 6, 2004, 407, 34);

INSERT INTO DisciplineEnrollments
VALUES(16, 7, 2004, 523, 112);

INSERT INTO DisciplineEnrollments
VALUES(16, 8, 2004, 548, 988);

INSERT INTO DisciplineEnrollments
VALUES(16, 10, 2004, 490, 5);

INSERT INTO DisciplineEnrollments
VALUES(16, 11, 2004, 133, 7);

INSERT INTO DisciplineEnrollments
VALUES(16, 12, 2004, 1021, 119);

INSERT INTO DisciplineEnrollments
VALUES(16, 13, 2004, 66, 0);

INSERT INTO DisciplineEnrollments
VALUES(16, 14, 2004, 1791, 27);

INSERT INTO DisciplineEnrollments
VALUES(16, 15, 2004, 538, 114);

INSERT INTO DisciplineEnrollments
VALUES(16, 17, 2004, 252, 60);

INSERT INTO DisciplineEnrollments
VALUES(16, 18, 2004, 139, 0);

INSERT INTO DisciplineEnrollments
VALUES(16, 19, 2004, 987, 108);

INSERT INTO DisciplineEnrollments
VALUES(16, 20, 2004, 1008, 345);

INSERT INTO DisciplineEnrollments
VALUES(16, 21, 2004, 909, 79);

INSERT INTO DisciplineEnrollments
VALUES(16, 22, 2004, 765, 0);

INSERT INTO DisciplineEnrollments
VALUES(17, 1, 2004, 2, 0);

INSERT INTO DisciplineEnrollments
VALUES(17, 2, 2004, 141, 58);

INSERT INTO DisciplineEnrollments
VALUES(17, 3, 2004, 46, 51);

INSERT INTO DisciplineEnrollments
VALUES(17, 4, 2004, 1227, 171);

INSERT INTO DisciplineEnrollments
VALUES(17, 5, 2004, 6004, 596);

INSERT INTO DisciplineEnrollments
VALUES(17, 6, 2004, 1100, 109);

INSERT INTO DisciplineEnrollments
VALUES(17, 7, 2004, 601, 325);

INSERT INTO DisciplineEnrollments
VALUES(17, 8, 2004, 1338, 842);

INSERT INTO DisciplineEnrollments
VALUES(17, 9, 2004, 1743, 304);

INSERT INTO DisciplineEnrollments
VALUES(17, 10, 2004, 1355, 127);

INSERT INTO DisciplineEnrollments
VALUES(17, 11, 2004, 259, 69);

INSERT INTO DisciplineEnrollments
VALUES(17, 12, 2004, 1439, 627);

INSERT INTO DisciplineEnrollments
VALUES(17, 13, 2004, 148, 22);

INSERT INTO DisciplineEnrollments
VALUES(17, 14, 2004, 1798, 86);

INSERT INTO DisciplineEnrollments
VALUES(17, 15, 2004, 1455, 229);

INSERT INTO DisciplineEnrollments
VALUES(17, 17, 2004, 268, 138);

INSERT INTO DisciplineEnrollments
VALUES(17, 18, 2004, 324, 133);

INSERT INTO DisciplineEnrollments
VALUES(17, 19, 2004, 1874, 146);

INSERT INTO DisciplineEnrollments
VALUES(17, 20, 2004, 1848, 459);

INSERT INTO DisciplineEnrollments
VALUES(17, 21, 2004, 2458, 323);

INSERT INTO DisciplineEnrollments
VALUES(17, 22, 2004, 1503, 0);

INSERT INTO DisciplineEnrollments
VALUES(18, 2, 2004, 200, 0);

INSERT INTO DisciplineEnrollments
VALUES(18, 3, 2004, 12, 0);

INSERT INTO DisciplineEnrollments
VALUES(18, 4, 2004, 1266, 142);

INSERT INTO DisciplineEnrollments
VALUES(18, 5, 2004, 4279, 741);

INSERT INTO DisciplineEnrollments
VALUES(18, 6, 2004, 1249, 62);

INSERT INTO DisciplineEnrollments
VALUES(18, 7, 2004, 934, 106);

INSERT INTO DisciplineEnrollments
VALUES(18, 8, 2004, 1378, 928);

INSERT INTO DisciplineEnrollments
VALUES(18, 9, 2004, 626, 95);

INSERT INTO DisciplineEnrollments
VALUES(18, 10, 2004, 2033, 187);

INSERT INTO DisciplineEnrollments
VALUES(18, 11, 2004, 235, 117);

INSERT INTO DisciplineEnrollments
VALUES(18, 12, 2004, 572, 512);

INSERT INTO DisciplineEnrollments
VALUES(18, 13, 2004, 468, 126);

INSERT INTO DisciplineEnrollments
VALUES(18, 14, 2004, 989, 132);

INSERT INTO DisciplineEnrollments
VALUES(18, 15, 2004, 1398, 792);

INSERT INTO DisciplineEnrollments
VALUES(18, 17, 2004, 124, 64);

INSERT INTO DisciplineEnrollments
VALUES(18, 18, 2004, 209, 113);

INSERT INTO DisciplineEnrollments
VALUES(18, 19, 2004, 1369, 117);

INSERT INTO DisciplineEnrollments
VALUES(18, 20, 2004, 663, 389);

INSERT INTO DisciplineEnrollments
VALUES(18, 21, 2004, 1981, 394);

INSERT INTO DisciplineEnrollments
VALUES(18, 22, 2004, 2736, 0);

INSERT INTO DisciplineEnrollments
VALUES(19, 1, 2004, 13, 0);

INSERT INTO DisciplineEnrollments
VALUES(19, 2, 2004, 44, 79);

INSERT INTO DisciplineEnrollments
VALUES(19, 4, 2004, 723, 85);

INSERT INTO DisciplineEnrollments
VALUES(19, 5, 2004, 4492, 295);

INSERT INTO DisciplineEnrollments
VALUES(19, 6, 2004, 834, 72);

INSERT INTO DisciplineEnrollments
VALUES(19, 7, 2004, 2025, 169);

INSERT INTO DisciplineEnrollments
VALUES(19, 8, 2004, 1520, 978);

INSERT INTO DisciplineEnrollments
VALUES(19, 9, 2004, 2784, 1893);

INSERT INTO DisciplineEnrollments
VALUES(19, 10, 2004, 1897, 141);

INSERT INTO DisciplineEnrollments
VALUES(19, 11, 2004, 99, 40);

INSERT INTO DisciplineEnrollments
VALUES(19, 12, 2004, 1607, 253);

INSERT INTO DisciplineEnrollments
VALUES(19, 13, 2004, 101, 114);

INSERT INTO DisciplineEnrollments
VALUES(19, 14, 2004, 441, 93);

INSERT INTO DisciplineEnrollments
VALUES(19, 15, 2004, 649, 291);

INSERT INTO DisciplineEnrollments
VALUES(19, 16, 2004, 0, 661);

INSERT INTO DisciplineEnrollments
VALUES(19, 17, 2004, 128, 49);

INSERT INTO DisciplineEnrollments
VALUES(19, 18, 2004, 192, 85);

INSERT INTO DisciplineEnrollments
VALUES(19, 19, 2004, 793, 123);

INSERT INTO DisciplineEnrollments
VALUES(19, 20, 2004, 882, 527);

INSERT INTO DisciplineEnrollments
VALUES(19, 21, 2004, 1091, 234);

INSERT INTO DisciplineEnrollments
VALUES(19, 22, 2004, 1348, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 1, 2004, 2631, 132);

INSERT INTO DisciplineEnrollments
VALUES(20, 2, 2004, 1177, 49);

INSERT INTO DisciplineEnrollments
VALUES(20, 4, 2004, 796, 24);

INSERT INTO DisciplineEnrollments
VALUES(20, 5, 2004, 1758, 60);

INSERT INTO DisciplineEnrollments
VALUES(20, 6, 2004, 210, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 7, 2004, 558, 39);

INSERT INTO DisciplineEnrollments
VALUES(20, 8, 2004, 903, 125);

INSERT INTO DisciplineEnrollments
VALUES(20, 9, 2004, 4943, 204);

INSERT INTO DisciplineEnrollments
VALUES(20, 10, 2004, 318, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 11, 2004, 51, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 13, 2004, 429, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 14, 2004, 392, 14);

INSERT INTO DisciplineEnrollments
VALUES(20, 15, 2004, 510, 36);

INSERT INTO DisciplineEnrollments
VALUES(20, 17, 2004, 252, 14);

INSERT INTO DisciplineEnrollments
VALUES(20, 18, 2004, 323, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 19, 2004, 267, 37);

INSERT INTO DisciplineEnrollments
VALUES(20, 20, 2004, 286, 12);

INSERT INTO DisciplineEnrollments
VALUES(20, 21, 2004, 764, 0);

INSERT INTO DisciplineEnrollments
VALUES(20, 22, 2004, 97, 0);

INSERT INTO DisciplineEnrollments
VALUES(21, 4, 2004, 304, 26);

INSERT INTO DisciplineEnrollments
VALUES(21, 5, 2004, 1733, 111);

INSERT INTO DisciplineEnrollments
VALUES(21, 6, 2004, 350, 0);

INSERT INTO DisciplineEnrollments
VALUES(21, 7, 2004, 224, 27);

INSERT INTO DisciplineEnrollments
VALUES(21, 8, 2004, 0, 238);

INSERT INTO DisciplineEnrollments
VALUES(21, 10, 2004, 144, 0);

INSERT INTO DisciplineEnrollments
VALUES(21, 11, 2004, 85, 4);

INSERT INTO DisciplineEnrollments
VALUES(21, 14, 2004, 1007, 0);

INSERT INTO DisciplineEnrollments
VALUES(21, 15, 2004, 199, 53);

INSERT INTO DisciplineEnrollments
VALUES(21, 17, 2004, 86, 13);

INSERT INTO DisciplineEnrollments
VALUES(21, 18, 2004, 65, 0);

INSERT INTO DisciplineEnrollments
VALUES(21, 19, 2004, 679, 26);

INSERT INTO DisciplineEnrollments
VALUES(21, 21, 2004, 862, 36);

INSERT INTO DisciplineEnrollments
VALUES(21, 22, 2004, 482, 1);

INSERT INTO DisciplineEnrollments
VALUES(22, 4, 2004, 287, 15);

INSERT INTO DisciplineEnrollments
VALUES(22, 5, 2004, 1132, 53);

INSERT INTO DisciplineEnrollments
VALUES(22, 6, 2004, 277, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 7, 2004, 163, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 8, 2004, 271, 244);

INSERT INTO DisciplineEnrollments
VALUES(22, 9, 2004, 0, 3);

INSERT INTO DisciplineEnrollments
VALUES(22, 10, 2004, 411, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 11, 2004, 56, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 12, 2004, 260, 48);

INSERT INTO DisciplineEnrollments
VALUES(22, 14, 2004, 770, 30);

INSERT INTO DisciplineEnrollments
VALUES(22, 15, 2004, 320, 40);

INSERT INTO DisciplineEnrollments
VALUES(22, 17, 2004, 88, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 18, 2004, 128, 0);

INSERT INTO DisciplineEnrollments
VALUES(22, 19, 2004, 478, 1);

INSERT INTO DisciplineEnrollments
VALUES(22, 20, 2004, 184, 39);

INSERT INTO DisciplineEnrollments
VALUES(22, 21, 2004, 1017, 43);

INSERT INTO DisciplineEnrollments
VALUES(22, 22, 2004, 1064, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 1, 2004, 25, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 4, 2004, 340, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 5, 2004, 967, 103);

INSERT INTO DisciplineEnrollments
VALUES(23, 6, 2004, 176, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 7, 2004, 243, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 8, 2004, 368, 247);

INSERT INTO DisciplineEnrollments
VALUES(23, 10, 2004, 220, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 11, 2004, 51, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 12, 2004, 380, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 14, 2004, 1212, 27);

INSERT INTO DisciplineEnrollments
VALUES(23, 15, 2004, 195, 36);

INSERT INTO DisciplineEnrollments
VALUES(23, 17, 2004, 123, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 18, 2004, 89, 0);

INSERT INTO DisciplineEnrollments
VALUES(23, 19, 2004, 395, 56);

INSERT INTO DisciplineEnrollments
VALUES(23, 20, 2004, 349, 207);

INSERT INTO DisciplineEnrollments
VALUES(23, 21, 2004, 593, 23);

INSERT INTO DisciplineEnrollments
VALUES(23, 22, 2004, 466, 0);

