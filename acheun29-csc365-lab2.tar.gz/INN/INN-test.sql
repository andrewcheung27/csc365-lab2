/* Author: Andrew Cheung */
/* Email: acheun29@calpoly.edu */


SELECT * FROM Reservations;
SELECT COUNT(*) FROM Reservations;


SELECT * FROM Rooms;
SELECT COUNT(*) FROM Rooms;


