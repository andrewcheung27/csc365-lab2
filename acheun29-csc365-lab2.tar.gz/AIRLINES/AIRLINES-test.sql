SELECT * FROM Flights;
SELECT COUNT(*) FROM Flights;


SELECT * FROM Airlines;
SELECT COUNT(*) FROM Airlines;


SELECT * FROM Airports100;
SELECT COUNT(*) FROM Airports100;


