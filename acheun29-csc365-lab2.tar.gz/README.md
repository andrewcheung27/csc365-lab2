# CSC 365 Lab 2 - Database Creation

## Author: Andrew Cheung
## Email: acheun29@calpoly.edu  
