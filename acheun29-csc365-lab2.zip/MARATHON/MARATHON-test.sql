SELECT * FROM Marathon;
SELECT COUNT(*) FROM Marathon;


