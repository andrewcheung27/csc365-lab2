INSERT INTO Continents
VALUES(1, 'america');

INSERT INTO Continents
VALUES(2, 'europe');

INSERT INTO Continents
VALUES(3, 'asia');

INSERT INTO Continents
VALUES(4, 'africa');

INSERT INTO Continents
VALUES(5, 'australia');

