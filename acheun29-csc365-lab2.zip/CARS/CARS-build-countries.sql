INSERT INTO Countries
VALUES(1, 'usa', 1);

INSERT INTO Countries
VALUES(2, 'germany', 2);

INSERT INTO Countries
VALUES(3, 'france', 2);

INSERT INTO Countries
VALUES(4, 'japan', 3);

INSERT INTO Countries
VALUES(5, 'italy', 2);

INSERT INTO Countries
VALUES(6, 'sweden', 2);

INSERT INTO Countries
VALUES(7, 'uk', 2);

INSERT INTO Countries
VALUES(8, 'korea', 3);

INSERT INTO Countries
VALUES(9, 'russia', 2);

INSERT INTO Countries
VALUES(10, 'nigeria', 4);

INSERT INTO Countries
VALUES(11, 'australia', 5);

INSERT INTO Countries
VALUES(12, 'new zealand', 5);

INSERT INTO Countries
VALUES(13, 'egypt', 4);

INSERT INTO Countries
VALUES(14, 'mexico', 1);

INSERT INTO Countries
VALUES(15, 'brazil', 1);

