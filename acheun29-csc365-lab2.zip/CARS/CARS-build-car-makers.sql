INSERT INTO CarMakers
VALUES(1, 'amc', 'American Motor Company', 1.0);

INSERT INTO CarMakers
VALUES(2, 'volkswagen', 'Volkswagen', 2.0);

INSERT INTO CarMakers
VALUES(3, 'bmw', 'BMW', 2.0);

INSERT INTO CarMakers
VALUES(4, 'gm', 'General Motors', 1.0);

INSERT INTO CarMakers
VALUES(5, 'ford', 'Ford Motor Company', 1.0);

INSERT INTO CarMakers
VALUES(6, 'chrysler', 'Chrysler', 1.0);

INSERT INTO CarMakers
VALUES(7, 'citroen', 'Citroen', 3.0);

INSERT INTO CarMakers
VALUES(8, 'nissan', 'Nissan Motors', 4.0);

INSERT INTO CarMakers
VALUES(9, 'fiat', 'Fiat', 5.0);

INSERT INTO CarMakers
VALUES(10, 'hi', 'hi', NULL);

INSERT INTO CarMakers
VALUES(11, 'honda', 'Honda', 4.0);

INSERT INTO CarMakers
VALUES(12, 'mazda', 'Mazda', 4.0);

INSERT INTO CarMakers
VALUES(13, 'daimler benz', 'Daimler Benz', 2.0);

INSERT INTO CarMakers
VALUES(14, 'opel', 'Opel', 2.0);

INSERT INTO CarMakers
VALUES(15, 'peugeaut', 'Peugeaut', 3.0);

INSERT INTO CarMakers
VALUES(16, 'renault', 'Renault', 3.0);

INSERT INTO CarMakers
VALUES(17, 'saab', 'Saab', 6.0);

INSERT INTO CarMakers
VALUES(18, 'subaru', 'Subaru', 4.0);

INSERT INTO CarMakers
VALUES(19, 'toyota', 'Toyota', 4.0);

INSERT INTO CarMakers
VALUES(20, 'triumph', 'Triumph', 7.0);

INSERT INTO CarMakers
VALUES(21, 'volvo', 'Volvo', 6.0);

INSERT INTO CarMakers
VALUES(22, 'kia', 'Kia Motors', 8.0);

INSERT INTO CarMakers
VALUES(23, 'hyundai', 'Hyundai', 8.0);

