SELECT * FROM CarMakers;
SELECT COUNT(*) FROM CarMakers;


SELECT * FROM CarNames;
SELECT COUNT(*) FROM CarNames;


SELECT * FROM CarsData;
SELECT COUNT(*) FROM CarsData;


SELECT * FROM Continents;
SELECT COUNT(*) FROM Continents;


SELECT * FROM Countries;
SELECT COUNT(*) FROM Countries;


SELECT * FROM ModelList;
SELECT COUNT(*) FROM ModelList;


