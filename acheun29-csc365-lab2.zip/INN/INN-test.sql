SELECT * FROM Reservations;
SELECT COUNT(*) FROM Reservations;


SELECT * FROM Rooms;
SELECT COUNT(*) FROM Rooms;


