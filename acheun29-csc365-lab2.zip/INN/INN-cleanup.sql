DROP TABLE Reservations;
DROP TABLE Rooms;
