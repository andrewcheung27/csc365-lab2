SELECT * FROM Campuses;
SELECT COUNT(*) FROM Campuses;


SELECT * FROM CsuFees;
SELECT COUNT(*) FROM CsuFees;


SELECT * FROM Degrees;
SELECT COUNT(*) FROM Degrees;


SELECT * FROM DisciplineEnrollments;
SELECT COUNT(*) FROM DisciplineEnrollments;


SELECT * FROM Disciplines;
SELECT COUNT(*) FROM Disciplines;


SELECT * FROM Enrollments;
SELECT COUNT(*) FROM Enrollments;


SELECT * FROM Faculty;
SELECT COUNT(*) FROM Faculty;


